from django.contrib import messages
from django.http import HttpRequest, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render

from accounts.models import UserRole
from accounts.permissions import role_required
from orders.forms import OrderForm
from orders.models import Order


@role_required(UserRole.ADMIN, UserRole.MANAGER)
def order_list(request: HttpRequest) -> HttpResponse:
    orders = (
        Order.objects.select_related("status", "pickup_point", "customer")
        .prefetch_related("items__product")
        .order_by("id")
    )
    return render(
        request,
        "orders/order_list.html",
        {
            "orders": orders,
            "page_title": "Заказы",
            "can_manage": request.user.role == UserRole.ADMIN,
            "can_view_orders": True,
        },
    )


@role_required(UserRole.ADMIN)
def order_create(request: HttpRequest) -> HttpResponse:
    if request.method == "POST":
        form = OrderForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Заказ успешно добавлен.")
            return redirect("orders:order_list")
    else:
        form = OrderForm()

    return render(
        request,
        "orders/order_form.html",
        {
            "form": form,
            "page_title": "Добавление заказа",
            "form_title": "Добавление заказа",
            "can_view_orders": True,
        },
    )


@role_required(UserRole.ADMIN)
def order_edit(request: HttpRequest, pk: int) -> HttpResponse:
    order = get_object_or_404(Order, pk=pk)
    if request.method == "POST":
        form = OrderForm(request.POST, instance=order)
        if form.is_valid():
            form.save()
            messages.success(request, "Изменения по заказу сохранены.")
            return redirect("orders:order_list")
    else:
        form = OrderForm(instance=order)

    return render(
        request,
        "orders/order_form.html",
        {
            "form": form,
            "page_title": "Редактирование заказа",
            "form_title": "Редактирование заказа",
            "order": order,
            "can_view_orders": True,
        },
    )


@role_required(UserRole.ADMIN)
def order_delete(request: HttpRequest, pk: int) -> HttpResponse:
    order = get_object_or_404(Order, pk=pk)
    if request.method == "POST":
        order.delete()
        messages.success(request, "Заказ удален.")
    return redirect("orders:order_list")
