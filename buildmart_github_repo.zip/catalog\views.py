from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import ProtectedError
from django.http import HttpRequest, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render

from accounts.models import UserRole
from accounts.permissions import role_required
from catalog.forms import ProductFilterForm, ProductForm
from catalog.models import Manufacturer, Product

PRODUCT_LOCK_KEY = "active_product_form"


def _current_role(request: HttpRequest) -> str:
    if request.user.is_authenticated:
        return request.user.role
    return "guest"


def _can_use_filters(request: HttpRequest) -> bool:
    return _current_role(request) in {UserRole.ADMIN, UserRole.MANAGER}


def _is_partial_request(request: HttpRequest) -> bool:
    return request.headers.get("x-requested-with") == "XMLHttpRequest"


def product_list(request: HttpRequest) -> HttpResponse:
    role = _current_role(request)
    queryset = Product.objects.with_related()
    filter_form = ProductFilterForm(request.GET or None)

    if _can_use_filters(request) and filter_form.is_valid():
        manufacturer = filter_form.cleaned_data.get("manufacturer")
        queryset = Product.objects.apply_live_filters(
            search_term=filter_form.cleaned_data.get("search", ""),
            manufacturer_id=manufacturer.pk if manufacturer else "",
            sort_key=filter_form.cleaned_data.get("sort", ""),
        )
    else:
        queryset = queryset.order_by("name", "article")

    context = {
        "page_title": "Товары",
        "products": queryset,
        "filter_form": filter_form,
        "role": role,
        "can_filter": _can_use_filters(request),
        "can_manage": role == UserRole.ADMIN,
        "can_view_orders": role in {UserRole.ADMIN, UserRole.MANAGER},
    }

    if _is_partial_request(request):
        return render(request, "catalog/partials/product_cards.html", context)

    return render(request, "catalog/product_list.html", context)


def _check_product_form_lock(request: HttpRequest, token: str) -> bool:
    active_token = request.session.get(PRODUCT_LOCK_KEY)
    if active_token and active_token != token:
        messages.warning(
            request,
            "Сначала завершите редактирование уже открытого товара.",
        )
        return False

    request.session[PRODUCT_LOCK_KEY] = token
    request.session.modified = True
    return True


def _release_product_form_lock(request: HttpRequest):
    if PRODUCT_LOCK_KEY in request.session:
        del request.session[PRODUCT_LOCK_KEY]
        request.session.modified = True


@role_required(UserRole.ADMIN)
def product_create(request: HttpRequest) -> HttpResponse:
    if not _check_product_form_lock(request, "create"):
        return redirect("catalog:product_list")

    if request.method == "POST":
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            _release_product_form_lock(request)
            messages.success(request, "Товар успешно добавлен.")
            return redirect("catalog:product_list")
    else:
        form = ProductForm()

    return render(
        request,
        "catalog/product_form.html",
        {
            "form": form,
            "page_title": "Добавление товара",
            "form_title": "Добавление товара",
        },
    )


@role_required(UserRole.ADMIN)
def product_edit(request: HttpRequest, pk: int) -> HttpResponse:
    product = get_object_or_404(Product.objects.with_related(), pk=pk)
    if not _check_product_form_lock(request, f"edit:{product.pk}"):
        return redirect("catalog:product_list")

    if request.method == "POST":
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            _release_product_form_lock(request)
            messages.success(request, "Изменения по товару сохранены.")
            return redirect("catalog:product_list")
    else:
        form = ProductForm(instance=product)

    return render(
        request,
        "catalog/product_form.html",
        {
            "form": form,
            "page_title": "Редактирование товара",
            "form_title": "Редактирование товара",
            "product": product,
        },
    )


@role_required(UserRole.ADMIN)
def release_product_form_lock(request: HttpRequest) -> HttpResponse:
    _release_product_form_lock(request)
    return redirect("catalog:product_list")


@role_required(UserRole.ADMIN)
def product_delete(request: HttpRequest, pk: int) -> HttpResponse:
    product = get_object_or_404(Product, pk=pk)
    if request.method != "POST":
        return redirect("catalog:product_list")

    try:
        product.delete()
        messages.success(request, "Товар удален.")
    except ProtectedError:
        messages.error(
            request,
            "Удаление невозможно: товар уже используется в заказе.",
        )
    return redirect("catalog:product_list")
