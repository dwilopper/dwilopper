@echo off
set "PS=C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_project_postgres.ps1"
if errorlevel 1 (
    echo.
    echo Project run failed.
    pause
    exit /b 1
)
