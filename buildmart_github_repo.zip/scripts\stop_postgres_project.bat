@echo off
set "PS=C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop_postgres_project.ps1"
if errorlevel 1 (
    echo.
    echo Stop failed.
    pause
    exit /b 1
)
