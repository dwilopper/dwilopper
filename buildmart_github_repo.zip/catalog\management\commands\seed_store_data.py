import shutil
from pathlib import Path

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.db import transaction
from openpyxl import load_workbook

from accounts.models import UserRole
from catalog.models import Manufacturer, Product, ProductCategory, Supplier, Unit
from orders.models import Order, OrderStatus, PickupPoint
from orders.services import parse_excel_date, parse_order_items

User = get_user_model()


class Command(BaseCommand):
    help = "Загружает стартовые данные магазина из Excel-файлов."

    def handle(self, *args, **options):
        seed_dir = Path(settings.BASE_DIR) / "seed" / "import"
        media_product_dir = Path(settings.MEDIA_ROOT) / "product_images"
        media_product_dir.mkdir(parents=True, exist_ok=True)

        with transaction.atomic():
            pickup_points = self.import_pickup_points(seed_dir / "pickup_points.xlsx")
            self.import_products(seed_dir / "products.xlsx", seed_dir, media_product_dir)
            self.import_users(seed_dir / "users.xlsx")
            self.import_orders(seed_dir / "orders.xlsx", pickup_points)

        self.stdout.write(self.style.SUCCESS("Стартовые данные успешно загружены."))

    def import_pickup_points(self, file_path: Path):
        workbook = load_workbook(file_path, data_only=True)
        sheet = workbook.active
        points = []
        for row in sheet.iter_rows(min_row=1, max_col=1, values_only=True):
            address = str(row[0]).strip() if row[0] else ""
            if not address:
                continue
            point, _ = PickupPoint.objects.update_or_create(
                address=address,
                defaults={"address": address},
            )
            points.append(point)
        return points

    def import_products(
        self,
        file_path: Path,
        seed_dir: Path,
        media_product_dir: Path,
    ):
        workbook = load_workbook(file_path, data_only=True)
        sheet = workbook.active
        headers = [cell.value for cell in sheet[1]]
        rows = [dict(zip(headers, row)) for row in sheet.iter_rows(min_row=2, values_only=True)]

        for row in rows:
            if not row["Артикул"]:
                continue

            category, _ = ProductCategory.objects.get_or_create(
                name=str(row["Категория товара"]).strip(),
            )
            manufacturer, _ = Manufacturer.objects.get_or_create(
                name=str(row["Производитель"]).strip(),
            )
            supplier, _ = Supplier.objects.get_or_create(
                name=str(row["Поставщик"]).strip(),
            )
            unit, _ = Unit.objects.get_or_create(
                name=str(row["Единица измерения"]).strip(),
            )

            product, _ = Product.objects.update_or_create(
                article=str(row["Артикул"]).strip(),
                defaults={
                    "name": str(row["Наименование товара"]).strip(),
                    "unit": unit,
                    "price": row["Цена"] or 0,
                    "supplier": supplier,
                    "manufacturer": manufacturer,
                    "category": category,
                    "discount_percent": int(row["Действующая скидка"] or 0),
                    "quantity_in_stock": int(row["Кол-во на складе"] or 0),
                    "description": str(row["Описание товара"]).strip(),
                },
            )

            photo_name = str(row["Фото"]).strip() if row["Фото"] else ""
            self.attach_product_image(product, photo_name, seed_dir, media_product_dir)

    def attach_product_image(
        self,
        product: Product,
        photo_name: str,
        seed_dir: Path,
        media_product_dir: Path,
    ):
        if not photo_name:
            if product.image:
                product.image.delete(save=False)
            return

        source_image = seed_dir / photo_name
        if not source_image.exists():
            if product.image:
                product.image.delete(save=False)
            return

        destination = media_product_dir / source_image.name
        if not destination.exists():
            shutil.copy2(source_image, destination)

        relative_image_path = f"product_images/{source_image.name}"
        if product.image.name != relative_image_path:
            product.image.name = relative_image_path
            product.save(update_fields=["image"])

    def import_users(self, file_path: Path):
        workbook = load_workbook(file_path, data_only=True)
        sheet = workbook.active
        headers = [cell.value for cell in sheet[1]]

        role_map = {
            "Администратор": UserRole.ADMIN,
            "Менеджер": UserRole.MANAGER,
            "Авторизированный клиент": UserRole.CLIENT,
        }

        first_admin_login = None
        for row in sheet.iter_rows(min_row=2, values_only=True):
            payload = dict(zip(headers, row))
            if not payload["Роль сотрудника"] or not payload["Логин"]:
                continue
            login = str(payload["Логин"]).strip()
            role = role_map[str(payload["Роль сотрудника"]).strip()]
            user, _ = User.objects.get_or_create(username=login)
            user.full_name = str(payload["ФИО"]).strip()
            user.role = role
            user.email = login
            user.is_staff = role == UserRole.ADMIN
            user.is_superuser = False
            if role == UserRole.ADMIN and first_admin_login is None:
                first_admin_login = login
                user.is_superuser = True
            user.set_password(str(payload["Пароль"]).strip())
            user.save()

    def import_orders(self, file_path: Path, pickup_points):
        workbook = load_workbook(file_path, data_only=True)
        sheet = workbook.active
        headers = [cell.value for cell in sheet[1]]

        for row in sheet.iter_rows(min_row=2, values_only=True):
            payload = dict(zip(headers, row))
            if not payload["Номер заказа"]:
                continue
            status, _ = OrderStatus.objects.get_or_create(
                name=str(payload["Статус заказа"]).strip(),
            )

            customer_name = str(payload["ФИО авторизированного клиента"]).strip()
            customer = User.objects.filter(
                full_name=customer_name,
                role=UserRole.CLIENT,
            ).first()

            pickup_index = int(payload["Адрес пункта выдачи"])
            pickup_point = pickup_points[pickup_index - 1]

            order, _ = Order.objects.update_or_create(
                id=int(payload["Номер заказа"]),
                defaults={
                    "customer": customer,
                    "status": status,
                    "pickup_point": pickup_point,
                    "order_date": parse_excel_date(payload["Дата заказа"]),
                    "delivery_date": parse_excel_date(payload["Дата доставки"]),
                    "pickup_code": int(payload["Код для получения"]),
                },
            )

            parsed_items = parse_order_items(str(payload["Артикул заказа"]).strip())
            order.replace_items(parsed_items)
