@echo off
set "PS=C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_postgres_project.ps1"
if errorlevel 1 (
    echo.
    echo Setup failed.
    pause
    exit /b 1
)
