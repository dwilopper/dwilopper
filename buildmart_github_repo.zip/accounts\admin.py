from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from accounts.models import User


@admin.register(User)
class StoreUserAdmin(UserAdmin):
    list_display = ("username", "full_name", "role", "is_staff")
    list_filter = ("role", "is_staff", "is_superuser", "is_active")
    ordering = ("full_name",)
    fieldsets = UserAdmin.fieldsets + (
        ("Профиль магазина", {"fields": ("full_name", "role")}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ("Профиль магазина", {"fields": ("full_name", "role")}),
    )
