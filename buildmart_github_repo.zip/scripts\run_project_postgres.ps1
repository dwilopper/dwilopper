. (Join-Path $PSScriptRoot "_postgres_common.ps1")

$config = Get-PortablePostgresConfig
Initialize-PortableCluster -Config $config
Start-PortablePostgres -Config $config
Set-DjangoPostgresEnv -Config $config

Write-Host "PostgreSQL is running on 127.0.0.1:$($config.Port)"
Write-Host "Django will use the real PostgreSQL database."
Write-Host ""

& $config.PythonExe $config.ManagePy runserver
