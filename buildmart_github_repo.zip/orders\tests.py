from datetime import date

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from accounts.models import UserRole
from catalog.models import Manufacturer, Product, ProductCategory, Supplier, Unit
from orders.models import Order, OrderItem, OrderStatus, PickupPoint

User = get_user_model()


class OrderAccessTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        category = ProductCategory.objects.create(name="Стеновые материалы")
        manufacturer = Manufacturer.objects.create(name="ЛСР")
        supplier = Supplier.objects.create(name="ЛСР")
        unit = Unit.objects.create(name="шт.")
        cls.product = Product.objects.create(
            article="ORDER1",
            name="Газобетон",
            category=category,
            manufacturer=manufacturer,
            supplier=supplier,
            unit=unit,
            price="50.00",
            discount_percent=0,
            quantity_in_stock=10,
            description="Тестовый газобетон",
        )
        cls.admin = User.objects.create_user(
            username="orders-admin@example.com",
            password="testpass123",
            full_name="Администратор Заказов",
            role=UserRole.ADMIN,
        )
        cls.manager = User.objects.create_user(
            username="orders-manager@example.com",
            password="testpass123",
            full_name="Менеджер Заказов",
            role=UserRole.MANAGER,
        )
        cls.client_user = User.objects.create_user(
            username="orders-client@example.com",
            password="testpass123",
            full_name="Клиент Заказов",
            role=UserRole.CLIENT,
        )
        cls.status = OrderStatus.objects.create(name="Завершен")
        cls.pickup_point = PickupPoint.objects.create(address="г. Лесной, ул. Новая, 1")
        cls.order = Order.objects.create(
            customer=cls.client_user,
            status=cls.status,
            pickup_point=cls.pickup_point,
            order_date=date(2025, 5, 1),
            delivery_date=date(2025, 5, 2),
            pickup_code=902,
        )
        OrderItem.objects.create(
            order=cls.order,
            product=cls.product,
            article_snapshot="ORDER1",
            quantity=1,
        )

    def test_manager_can_open_orders(self):
        self.client.login(username="orders-manager@example.com", password="testpass123")
        response = self.client.get(reverse("orders:order_list"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "ORDER1, 1")

    def test_client_cannot_open_orders(self):
        self.client.login(username="orders-client@example.com", password="testpass123")
        response = self.client.get(reverse("orders:order_list"))
        self.assertRedirects(response, reverse("catalog:product_list"))

    def test_admin_can_create_order(self):
        self.client.login(username="orders-admin@example.com", password="testpass123")
        response = self.client.post(
            reverse("orders:order_create"),
            {
                "article_items": "ORDER1, 3",
                "status": self.status.pk,
                "pickup_point": self.pickup_point.pk,
                "order_date": "2025-06-01",
                "delivery_date": "2025-06-03",
            },
        )
        self.assertRedirects(response, reverse("orders:order_list"))
        self.assertEqual(Order.objects.count(), 2)
