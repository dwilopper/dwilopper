from django import forms

from orders.models import Order
from orders.services import parse_order_items


class OrderForm(forms.ModelForm):
    order_id = forms.IntegerField(label="Номер заказа", disabled=True, required=False)
    article_items = forms.CharField(
        label="Артикул заказа",
        widget=forms.Textarea(
            attrs={
                "class": "form-control",
                "rows": 4,
                "placeholder": "Например: PMEZMH, 2, BPV4MM, 1",
            }
        ),
    )

    class Meta:
        model = Order
        fields = [
            "status",
            "pickup_point",
            "order_date",
            "delivery_date",
        ]
        widgets = {
            "status": forms.Select(attrs={"class": "form-control"}),
            "pickup_point": forms.Select(attrs={"class": "form-control"}),
            "order_date": forms.DateInput(
                attrs={"class": "form-control", "type": "date"}
            ),
            "delivery_date": forms.DateInput(
                attrs={"class": "form-control", "type": "date"}
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.pk:
            self.fields["order_id"].initial = self.instance.pk
            self.fields["article_items"].initial = self.instance.items_summary

    def clean_article_items(self):
        article_items = self.cleaned_data["article_items"]
        self.parsed_items = parse_order_items(article_items)
        return article_items

    def clean(self):
        cleaned_data = super().clean()
        order_date = cleaned_data.get("order_date")
        delivery_date = cleaned_data.get("delivery_date")
        if order_date and delivery_date and delivery_date < order_date:
            self.add_error(
                "delivery_date",
                "Дата доставки не может быть раньше даты заказа.",
            )
        return cleaned_data

    def save(self, commit=True):
        order = super().save(commit=commit)
        if commit:
            order.replace_items(self.parsed_items)
        return order
