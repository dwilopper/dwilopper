. (Join-Path $PSScriptRoot "_postgres_common.ps1")

$config = Get-PortablePostgresConfig
Initialize-PortableCluster -Config $config
Start-PortablePostgres -Config $config

$psqlExe = Join-Path $config.BinDir "psql.exe"
$roleExistsSql = "SELECT 1 FROM pg_roles WHERE rolname = '$($config.DbUser)';"
$roleExists = $roleExistsSql | & $psqlExe -h 127.0.0.1 -p $config.Port -U postgres -d postgres -t -A

if ($roleExists) {
    Invoke-PostgresSql -Config $config -Sql "ALTER ROLE $($config.DbUser) WITH LOGIN PASSWORD '$($config.DbPassword)';"
} else {
    Invoke-PostgresSql -Config $config -Sql "CREATE ROLE $($config.DbUser) LOGIN PASSWORD '$($config.DbPassword)';"
}

$existsSql = "SELECT 1 FROM pg_database WHERE datname = '$($config.DbName)';"
$databaseExists = $existsSql | & $psqlExe -h 127.0.0.1 -p $config.Port -U postgres -d postgres -t -A

if (-not $databaseExists) {
    Invoke-PostgresSql -Config $config -Sql "CREATE DATABASE $($config.DbName) OWNER $($config.DbUser);"
}

Set-DjangoPostgresEnv -Config $config

& $config.PythonExe $config.ManagePy migrate
& $config.PythonExe $config.ManagePy seed_store_data

$dumpPath = Join-Path $config.DatabaseDir "buildmart_store.sql"
$pgDumpExe = Join-Path $config.BinDir "pg_dump.exe"
& $pgDumpExe -h 127.0.0.1 -p $config.Port -U postgres -d $config.DbName -f $dumpPath

Write-Host ""
Write-Host "PostgreSQL setup complete."
Write-Host "Port: $($config.Port)"
Write-Host "Database: $($config.DbName)"
Write-Host "DB user: $($config.DbUser)"
Write-Host "SQL dump: $dumpPath"
