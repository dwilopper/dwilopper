DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'buildmart_user') THEN
        CREATE ROLE buildmart_user WITH LOGIN PASSWORD 'buildmart_password';
    END IF;
END
$$;

-- Run the CREATE DATABASE statement separately if the database does not exist.
CREATE DATABASE buildmart_store
    WITH
    OWNER = buildmart_user
    ENCODING = 'UTF8';

GRANT ALL PRIVILEGES ON DATABASE buildmart_store TO buildmart_user;
