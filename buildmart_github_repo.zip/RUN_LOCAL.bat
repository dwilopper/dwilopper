@echo off
cd /d "%~dp0"
title BuildMart Run

if not exist ".venv\Scripts\python.exe" (
    echo The project is not prepared yet.
    echo Run SETUP_LOCAL.bat first.
    pause
    exit /b 1
)

if not exist ".env" (
    copy /Y ".env.example" ".env" >nul
)

echo Open this address in your browser:
echo http://127.0.0.1:8000/login/
echo.
echo Keep this window open while the site is running.
echo.
".\.venv\Scripts\python.exe" manage.py runserver
pause
