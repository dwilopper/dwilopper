from functools import wraps

from django.contrib import messages
from django.shortcuts import redirect


def role_required(*allowed_roles):
    def decorator(view_func):
        @wraps(view_func)
        def wrapped_view(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect("accounts:login")

            if request.user.role not in allowed_roles:
                messages.error(
                    request,
                    "У вас нет прав для выполнения этого действия.",
                )
                return redirect("catalog:product_list")

            return view_func(request, *args, **kwargs)

        return wrapped_view

    return decorator
