from datetime import date, datetime
import calendar

from django.core.exceptions import ValidationError

from catalog.models import Product


def normalize_article(raw_article: str) -> str:
    article = raw_article.strip()
    if Product.objects.filter(article=article).exists():
        return article

    if article and article[-1].isdigit():
        shortened = article[:-1]
        if Product.objects.filter(article=shortened).exists():
            return shortened

    raise ValidationError(f"Товар с артикулом '{article}' не найден.")


def parse_order_items(items_text: str):
    tokens = [token.strip() for token in items_text.split(",") if token.strip()]
    if len(tokens) < 2 or len(tokens) % 2 != 0:
        raise ValidationError(
            "Используйте формат: АРТИКУЛ, КОЛИЧЕСТВО, АРТИКУЛ, КОЛИЧЕСТВО.",
        )

    parsed_items = []
    for index in range(0, len(tokens), 2):
        raw_article = tokens[index]
        quantity_token = tokens[index + 1]
        normalized_article = normalize_article(raw_article)
        try:
            quantity = int(quantity_token)
        except ValueError as exc:
            raise ValidationError(
                f"Количество '{quantity_token}' должно быть целым числом.",
            ) from exc

        if quantity <= 0:
            raise ValidationError("Количество товара в заказе должно быть больше нуля.")

        parsed_items.append(
            {
                "raw_article": raw_article,
                "product": Product.objects.get(article=normalized_article),
                "quantity": quantity,
            }
        )

    return parsed_items


def parse_excel_date(raw_value):
    if isinstance(raw_value, datetime):
        return raw_value.date()
    if isinstance(raw_value, date):
        return raw_value

    text_value = str(raw_value).strip()
    if not text_value:
        raise ValidationError("Дата не заполнена.")

    for date_format in ("%Y-%m-%d", "%d.%m.%Y"):
        try:
            return datetime.strptime(text_value, date_format).date()
        except ValueError:
            continue

    if "." in text_value:
        day, month, year = [int(part) for part in text_value.split(".")]
        last_day = calendar.monthrange(year, month)[1]
        return date(year, month, min(day, last_day))

    raise ValidationError(f"Не удалось распознать дату '{text_value}'.")
