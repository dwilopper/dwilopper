from decimal import Decimal

from django.core.files.images import get_image_dimensions
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models


class NamedDirectoryModel(models.Model):
    name = models.CharField("Наименование", max_length=255, unique=True)

    class Meta:
        abstract = True
        ordering = ["name"]

    def __str__(self):
        return self.name


class ProductCategory(NamedDirectoryModel):
    class Meta(NamedDirectoryModel.Meta):
        verbose_name = "Категория товара"
        verbose_name_plural = "Категории товаров"


class Manufacturer(NamedDirectoryModel):
    class Meta(NamedDirectoryModel.Meta):
        verbose_name = "Производитель"
        verbose_name_plural = "Производители"


class Supplier(NamedDirectoryModel):
    class Meta(NamedDirectoryModel.Meta):
        verbose_name = "Поставщик"
        verbose_name_plural = "Поставщики"


class Unit(NamedDirectoryModel):
    class Meta(NamedDirectoryModel.Meta):
        verbose_name = "Единица измерения"
        verbose_name_plural = "Единицы измерения"


class ProductQuerySet(models.QuerySet):
    def with_related(self):
        return self.select_related(
            "unit",
            "supplier",
            "manufacturer",
            "category",
        )

    def apply_live_filters(self, search_term="", manufacturer_id="", sort_key=""):
        queryset = self.with_related()

        if search_term:
            search = search_term.strip()
            queryset = queryset.filter(
                models.Q(article__icontains=search)
                | models.Q(name__icontains=search)
                | models.Q(description__icontains=search)
                | models.Q(manufacturer__name__icontains=search)
                | models.Q(supplier__name__icontains=search)
                | models.Q(category__name__icontains=search)
                | models.Q(unit__name__icontains=search)
            )

        if manufacturer_id:
            queryset = queryset.filter(manufacturer_id=manufacturer_id)

        sort_map = {
            "quantity_asc": "quantity_in_stock",
            "quantity_desc": "-quantity_in_stock",
            "price_asc": "price",
            "price_desc": "-price",
            "discount_asc": "discount_percent",
            "discount_desc": "-discount_percent",
        }
        if sort_key in sort_map:
            queryset = queryset.order_by(sort_map[sort_key], "name")
        else:
            queryset = queryset.order_by("name", "article")

        return queryset


class Product(models.Model):
    article = models.CharField("Артикул", max_length=16, unique=True)
    name = models.CharField("Наименование товара", max_length=255)
    unit = models.ForeignKey(
        Unit,
        verbose_name="Единица измерения",
        on_delete=models.PROTECT,
        related_name="products",
    )
    price = models.DecimalField(
        "Цена",
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0"))],
    )
    supplier = models.ForeignKey(
        Supplier,
        verbose_name="Поставщик",
        on_delete=models.PROTECT,
        related_name="products",
    )
    manufacturer = models.ForeignKey(
        Manufacturer,
        verbose_name="Производитель",
        on_delete=models.PROTECT,
        related_name="products",
    )
    category = models.ForeignKey(
        ProductCategory,
        verbose_name="Категория товара",
        on_delete=models.PROTECT,
        related_name="products",
    )
    discount_percent = models.PositiveSmallIntegerField(
        "Действующая скидка",
        default=0,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
    )
    quantity_in_stock = models.PositiveIntegerField(
        "Количество на складе",
        default=0,
        validators=[MinValueValidator(0)],
    )
    description = models.TextField("Описание товара")
    image = models.ImageField(
        "Фото",
        upload_to="product_images/",
        blank=True,
        null=True,
    )
    objects = ProductQuerySet.as_manager()

    class Meta:
        ordering = ["name", "article"]
        verbose_name = "Товар"
        verbose_name_plural = "Товары"

    def __str__(self):
        return f"{self.name} ({self.article})"

    @property
    def discounted_price(self) -> Decimal:
        discount_ratio = Decimal(100 - self.discount_percent) / Decimal(100)
        return (self.price * discount_ratio).quantize(Decimal("0.01"))

    @property
    def has_discount(self) -> bool:
        return self.discount_percent > 0 and self.discounted_price < self.price

    @property
    def highlight_class(self) -> str:
        if self.quantity_in_stock == 0:
            return "product-card--empty"
        if self.discount_percent > 12:
            return "product-card--discount"
        return ""

    def save(self, *args, **kwargs):
        previous_image = None
        if self.pk:
            previous_image = (
                Product.objects.filter(pk=self.pk)
                .values_list("image", flat=True)
                .first()
            )

        super().save(*args, **kwargs)

        if self.image:
            self._resize_image_if_needed()

        if previous_image and previous_image != self.image.name:
            storage = self.image.storage
            if storage.exists(previous_image):
                storage.delete(previous_image)

    def delete(self, *args, **kwargs):
        image_name = self.image.name if self.image else None
        super().delete(*args, **kwargs)
        if image_name and self.image.storage.exists(image_name):
            self.image.storage.delete(image_name)

    def _resize_image_if_needed(self):
        width, height = get_image_dimensions(self.image)
        if width <= 300 and height <= 200:
            return

        from PIL import Image

        image_path = self.image.path
        with Image.open(image_path) as image:
            image.thumbnail((300, 200))
            image.save(image_path)
