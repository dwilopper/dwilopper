from django.core.validators import MinValueValidator
from django.db import models

from accounts.models import User
from catalog.models import Product


class PickupPoint(models.Model):
    address = models.CharField("Адрес пункта выдачи", max_length=255, unique=True)

    class Meta:
        ordering = ["id"]
        verbose_name = "Пункт выдачи"
        verbose_name_plural = "Пункты выдачи"

    def __str__(self):
        return self.address


class OrderStatus(models.Model):
    name = models.CharField("Статус заказа", max_length=100, unique=True)

    class Meta:
        ordering = ["name"]
        verbose_name = "Статус заказа"
        verbose_name_plural = "Статусы заказов"

    def __str__(self):
        return self.name


class Order(models.Model):
    customer = models.ForeignKey(
        User,
        verbose_name="Клиент",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="orders",
    )
    status = models.ForeignKey(
        OrderStatus,
        verbose_name="Статус заказа",
        on_delete=models.PROTECT,
        related_name="orders",
    )
    pickup_point = models.ForeignKey(
        PickupPoint,
        verbose_name="Пункт выдачи",
        on_delete=models.PROTECT,
        related_name="orders",
    )
    order_date = models.DateField("Дата заказа")
    delivery_date = models.DateField("Дата доставки")
    pickup_code = models.PositiveIntegerField(
        "Код для получения",
        blank=True,
        null=True,
        validators=[MinValueValidator(1)],
    )

    class Meta:
        ordering = ["id"]
        verbose_name = "Заказ"
        verbose_name_plural = "Заказы"

    def __str__(self):
        return f"Заказ №{self.pk}"

    def save(self, *args, **kwargs):
        if not self.pickup_code:
            self.pickup_code = self.generate_next_pickup_code()
        super().save(*args, **kwargs)

    def generate_next_pickup_code(self) -> int:
        last_code = (
            Order.objects.exclude(pk=self.pk)
            .order_by("-pickup_code")
            .values_list("pickup_code", flat=True)
            .first()
        )
        return (last_code or 900) + 1

    @property
    def items_summary(self) -> str:
        return ", ".join(item.display_text for item in self.items.select_related("product"))

    def replace_items(self, parsed_items):
        self.items.all().delete()
        OrderItem.objects.bulk_create(
            [
                OrderItem(
                    order=self,
                    product=item["product"],
                    article_snapshot=item["raw_article"],
                    quantity=item["quantity"],
                )
                for item in parsed_items
            ]
        )


class OrderItem(models.Model):
    order = models.ForeignKey(
        Order,
        on_delete=models.CASCADE,
        related_name="items",
        verbose_name="Заказ",
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name="order_items",
        verbose_name="Товар",
    )
    article_snapshot = models.CharField("Артикул из заказа", max_length=16)
    quantity = models.PositiveIntegerField(
        "Количество",
        validators=[MinValueValidator(1)],
    )

    class Meta:
        verbose_name = "Позиция заказа"
        verbose_name_plural = "Позиции заказа"

    def __str__(self):
        return f"{self.display_article} x {self.quantity}"

    @property
    def display_article(self) -> str:
        return self.product.article if self.product_id else self.article_snapshot

    @property
    def display_text(self) -> str:
        return f"{self.display_article}, {self.quantity}"
