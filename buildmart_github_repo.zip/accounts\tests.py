from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from accounts.models import UserRole

User = get_user_model()


class AuthenticationFlowTests(TestCase):
    def test_login_page_opens(self):
        response = self.client.get(reverse("accounts:login"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Авторизация")

    def test_valid_login_redirects_to_catalog(self):
        User.objects.create_user(
            username="login@example.com",
            password="testpass123",
            full_name="Пользователь Логина",
            role=UserRole.CLIENT,
        )
        response = self.client.post(
            reverse("accounts:login"),
            {"username": "login@example.com", "password": "testpass123"},
        )
        self.assertRedirects(response, reverse("catalog:product_list"))

    def test_logout_with_post_redirects_to_login(self):
        User.objects.create_user(
            username="logout@example.com",
            password="testpass123",
            full_name="Пользователь Выхода",
            role=UserRole.CLIENT,
        )
        self.client.login(username="logout@example.com", password="testpass123")
        response = self.client.post(reverse("accounts:logout"))
        self.assertRedirects(response, reverse("accounts:login"))
