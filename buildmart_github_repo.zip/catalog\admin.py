from django.contrib import admin

from catalog.models import (
    Manufacturer,
    Product,
    ProductCategory,
    Supplier,
    Unit,
)

admin.site.register(ProductCategory)
admin.site.register(Manufacturer)
admin.site.register(Supplier)
admin.site.register(Unit)


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = (
        "article",
        "name",
        "category",
        "manufacturer",
        "price",
        "discount_percent",
        "quantity_in_stock",
    )
    list_filter = ("category", "manufacturer", "supplier")
    search_fields = ("article", "name", "description")
