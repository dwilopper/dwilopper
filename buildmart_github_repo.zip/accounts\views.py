from django.contrib.auth.views import LoginView, LogoutView
from django.shortcuts import redirect
from django.urls import reverse_lazy

from accounts.forms import LoginForm


class StoreLoginView(LoginView):
    authentication_form = LoginForm
    template_name = "accounts/login.html"
    redirect_authenticated_user = True

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["page_title"] = "Авторизация"
        context["hide_header"] = True
        return context

    def get_success_url(self):
        return self.get_redirect_url() or reverse_lazy("catalog:product_list")


class StoreLogoutView(LogoutView):
    next_page = reverse_lazy("accounts:login")


def home_redirect(request):
    if request.user.is_authenticated:
        return redirect("catalog:product_list")
    return redirect("accounts:login")
