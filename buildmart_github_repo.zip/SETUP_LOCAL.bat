@echo off
cd /d "%~dp0"
title BuildMart Setup

echo ==========================================
echo         BUILDING LOCAL PROJECT
echo ==========================================
echo.

if not exist ".env" (
    copy /Y ".env.example" ".env" >nul
    echo Created .env from .env.example
    echo If your PostgreSQL port/login/password are different, edit .env and run this file again.
    echo.
)

set "PYTHON_CMD="
where py >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=py"

if not defined PYTHON_CMD (
    where python >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=python"
)

if not defined PYTHON_CMD goto no_python

if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    %PYTHON_CMD% -m venv .venv
    if errorlevel 1 goto fail
)

echo Installing dependencies...
".\.venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto fail

".\.venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto fail

echo.
echo Applying migrations...
".\.venv\Scripts\python.exe" manage.py migrate
if errorlevel 1 goto fail

for /f %%i in ('".\.venv\Scripts\python.exe" -c "import os; os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings'); import django; django.setup(); from catalog.models import Product; print(1 if Product.objects.exists() else 0)"') do set "HAS_DATA=%%i"

if "%HAS_DATA%"=="1" goto skip_data

echo Loading initial data...
".\.venv\Scripts\python.exe" manage.py loaddata database\initial_data.json
if errorlevel 1 goto fail
goto checks

:skip_data
echo Database already contains products. Fixture loading skipped.

:checks
echo.
echo Running Django check...
".\.venv\Scripts\python.exe" manage.py check
if errorlevel 1 goto fail

echo.
echo Setup complete.
echo Next step: run RUN_LOCAL.bat
pause
exit /b 0

:no_python
echo Python was not found.
echo Install Python 3.12+ and run this file again.
pause
exit /b 1

:fail
echo.
echo Setup failed.
echo Most often the reason is that PostgreSQL database/user are not created yet.
echo Check pgAdmin and .env, then run this file again.
pause
exit /b 1
