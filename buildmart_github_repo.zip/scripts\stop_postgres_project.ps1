. (Join-Path $PSScriptRoot "_postgres_common.ps1")

$config = Get-PortablePostgresConfig
Stop-PortablePostgres -Config $config

Write-Host "Portable PostgreSQL stopped."
