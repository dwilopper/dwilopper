@echo off
cd /d "%~dp0"
title BuildMart Stop
echo Stopping PostgreSQL...
call "%~dp0scripts\stop_postgres_project.bat"
echo Done.
pause
