const form = document.querySelector("[data-live-filter-form]");
const fragment = document.querySelector("#product-list-fragment");

if (form && fragment) {
    let timerId = null;

    const renderFilteredProducts = async () => {
        const params = new URLSearchParams(new FormData(form));
        const url = `${window.location.pathname}?${params.toString()}`;

        const response = await fetch(url, {
            headers: {
                "X-Requested-With": "XMLHttpRequest",
            },
        });

        if (!response.ok) {
            return;
        }

        fragment.innerHTML = await response.text();
        window.history.replaceState({}, "", url);
    };

    const queueRender = () => {
        window.clearTimeout(timerId);
        timerId = window.setTimeout(renderFilteredProducts, 180);
    };

    form.addEventListener("input", queueRender);
    form.addEventListener("change", queueRender);
}
