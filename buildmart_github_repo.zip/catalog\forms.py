from django import forms

from catalog.models import Manufacturer, Product


class ProductForm(forms.ModelForm):
    product_id = forms.IntegerField(label="ID", disabled=True, required=False)

    class Meta:
        model = Product
        fields = [
            "article",
            "name",
            "category",
            "description",
            "manufacturer",
            "supplier",
            "price",
            "unit",
            "quantity_in_stock",
            "discount_percent",
            "image",
        ]
        widgets = {
            "article": forms.TextInput(attrs={"class": "form-control"}),
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "category": forms.Select(attrs={"class": "form-control"}),
            "description": forms.Textarea(
                attrs={
                    "class": "form-control form-control--autogrow",
                    "rows": 4,
                    "data-autogrow": "true",
                }
            ),
            "manufacturer": forms.Select(attrs={"class": "form-control"}),
            "supplier": forms.Select(attrs={"class": "form-control"}),
            "price": forms.NumberInput(
                attrs={"class": "form-control", "step": "0.01", "min": "0"}
            ),
            "unit": forms.Select(attrs={"class": "form-control"}),
            "quantity_in_stock": forms.NumberInput(
                attrs={"class": "form-control", "min": "0"}
            ),
            "discount_percent": forms.NumberInput(
                attrs={"class": "form-control", "min": "0", "max": "100"}
            ),
            "image": forms.ClearableFileInput(attrs={"class": "form-control"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.pk:
            self.fields["product_id"].initial = self.instance.pk


class ProductFilterForm(forms.Form):
    search = forms.CharField(required=False)
    manufacturer = forms.ModelChoiceField(
        queryset=Manufacturer.objects.all(),
        required=False,
        empty_label="Все производители",
    )
    sort = forms.ChoiceField(
        required=False,
        choices=[
            ("", "Без сортировки"),
            ("quantity_asc", "Остаток: по возрастанию"),
            ("quantity_desc", "Остаток: по убыванию"),
            ("price_asc", "Цена: по возрастанию"),
            ("price_desc", "Цена: по убыванию"),
            ("discount_asc", "Скидка: по возрастанию"),
            ("discount_desc", "Скидка: по убыванию"),
        ],
    )
