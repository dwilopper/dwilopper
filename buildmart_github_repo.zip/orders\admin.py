from django.contrib import admin

from orders.models import Order, OrderItem, OrderStatus, PickupPoint

admin.site.register(PickupPoint)
admin.site.register(OrderStatus)


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("id", "status", "pickup_point", "order_date", "delivery_date")
    list_filter = ("status",)
    inlines = [OrderItemInline]
