$ErrorActionPreference = "Stop"

function Get-ProjectRoot {
    (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
}

function Ensure-ProjectDrive {
    $projectRoot = Get-ProjectRoot
    $candidate = "P:"

    cmd /c "subst $candidate /d" > $null 2>&1
    subst $candidate $projectRoot > $null

    return $candidate
}

function Get-PortablePostgresConfig {
    $drive = Ensure-ProjectDrive
    $root = "$drive\"

    @{
        Drive = $drive
        ProjectRoot = $root.TrimEnd("\")
        PgRoot = Join-Path $root "work\portable_postgres\pgsql"
        BinDir = Join-Path $root "work\portable_postgres\pgsql\bin"
        DataDir = Join-Path $root "work\portable_postgres\data"
        DatabaseDir = Join-Path $root "database"
        PythonExe = Join-Path $root ".venv\Scripts\python.exe"
        ManagePy = Join-Path $root "manage.py"
        Port = 5433
        DbName = "buildmart_store"
        DbUser = "buildmart_user"
        DbPassword = "buildmart_password"
    }
}

function Assert-PortablePostgresExtracted {
    param($Config)

    $postgresExe = Join-Path $Config.BinDir "postgres.exe"
    if (-not (Test-Path $postgresExe)) {
        throw "Portable PostgreSQL was not found in work\\portable_postgres\\pgsql\\bin."
    }
}

function Test-PostgresReady {
    param($Config)

    $pgIsReady = Join-Path $Config.BinDir "pg_isready.exe"
    & $pgIsReady -h 127.0.0.1 -p $Config.Port *> $null
    $LASTEXITCODE -eq 0
}

function Wait-PostgresReady {
    param($Config)

    for ($i = 0; $i -lt 40; $i++) {
        Start-Sleep -Milliseconds 500
        if (Test-PostgresReady -Config $Config) {
            return
        }
    }

    throw "PostgreSQL did not become ready on port $($Config.Port)."
}

function Start-PortablePostgres {
    param($Config)

    Assert-PortablePostgresExtracted -Config $Config

    if (Test-PostgresReady -Config $Config) {
        return
    }

    $postgresExe = Join-Path $Config.BinDir "postgres.exe"
    Start-Process `
        -FilePath $postgresExe `
        -ArgumentList "-D", $Config.DataDir, "-p", $Config.Port `
        -WorkingDirectory $Config.ProjectRoot `
        -WindowStyle Hidden | Out-Null

    Wait-PostgresReady -Config $Config
}

function Stop-PortablePostgres {
    param($Config)

    Get-Process postgres -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
}

function Initialize-PortableCluster {
    param($Config)

    if (Test-Path (Join-Path $Config.DataDir "PG_VERSION")) {
        return
    }

    New-Item -ItemType Directory -Force -Path $Config.DataDir | Out-Null
    $initdbExe = Join-Path $Config.BinDir "initdb.exe"
    & $initdbExe -D $Config.DataDir -U postgres -A trust -E UTF8 --locale=C
}

function Invoke-PostgresSql {
    param(
        $Config,
        [string]$Database = "postgres",
        [string]$Sql
    )

    $psqlExe = Join-Path $Config.BinDir "psql.exe"
    $Sql | & $psqlExe -h 127.0.0.1 -p $Config.Port -U postgres -d $Database
}

function Set-DjangoPostgresEnv {
    param($Config)

    $env:POSTGRES_DB = $Config.DbName
    $env:POSTGRES_USER = $Config.DbUser
    $env:POSTGRES_PASSWORD = $Config.DbPassword
    $env:POSTGRES_HOST = "127.0.0.1"
    $env:POSTGRES_PORT = [string]$Config.Port
    $env:DJANGO_DEBUG = "1"
    $env:DJANGO_SECRET_KEY = "django-insecure-buildmart-demo-key"
}
