@echo off
cd /d "%~dp0"
title BuildMart Start

echo ==========================================
echo         STARTING THE WEBSITE
echo ==========================================
echo.
echo Step 1: Preparing PostgreSQL...
call "%~dp0scripts\setup_postgres_project.bat"
if errorlevel 1 goto fail

echo.
echo Step 2: Starting the website...
echo Open this address in your browser:
echo http://127.0.0.1:8000/login/
echo.
echo Keep this window open while the site is running.
echo.
call "%~dp0scripts\run_project_postgres.bat"
goto end

:fail
echo.
echo The site did not start.
echo Send me a screenshot of this window if it happens again.
pause
exit /b 1

:end
pause
