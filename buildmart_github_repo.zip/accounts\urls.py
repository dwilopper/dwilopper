from django.urls import path

from accounts.views import StoreLoginView, StoreLogoutView, home_redirect

app_name = "accounts"

urlpatterns = [
    path("", home_redirect, name="home"),
    path("login/", StoreLoginView.as_view(), name="login"),
    path("logout/", StoreLogoutView.as_view(), name="logout"),
]
