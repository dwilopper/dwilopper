from datetime import date

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from accounts.models import UserRole
from catalog.models import Manufacturer, Product, ProductCategory, Supplier, Unit
from orders.models import Order, OrderItem, OrderStatus, PickupPoint

User = get_user_model()


class CatalogAccessTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.category = ProductCategory.objects.create(name="Общестроительные материалы")
        cls.manufacturer = Manufacturer.objects.create(name="Knauf")
        cls.supplier = Supplier.objects.create(name="Knauf")
        cls.unit = Unit.objects.create(name="шт.")
        cls.product = Product.objects.create(
            article="TEST01",
            name="Тестовый товар",
            category=cls.category,
            manufacturer=cls.manufacturer,
            supplier=cls.supplier,
            unit=cls.unit,
            price="100.00",
            discount_percent=15,
            quantity_in_stock=7,
            description="Описание тестового товара",
        )
        cls.admin = User.objects.create_user(
            username="admin@example.com",
            password="testpass123",
            full_name="Администратор Тестовый",
            role=UserRole.ADMIN,
        )
        cls.client_user = User.objects.create_user(
            username="client@example.com",
            password="testpass123",
            full_name="Клиент Тестовый",
            role=UserRole.CLIENT,
        )
        cls.manager = User.objects.create_user(
            username="manager@example.com",
            password="testpass123",
            full_name="Менеджер Тестовый",
            role=UserRole.MANAGER,
        )
        cls.status = OrderStatus.objects.create(name="Новый")
        cls.pickup_point = PickupPoint.objects.create(address="г. Лесной, ул. Тестовая, 1")
        cls.order = Order.objects.create(
            customer=cls.client_user,
            status=cls.status,
            pickup_point=cls.pickup_point,
            order_date=date(2025, 4, 1),
            delivery_date=date(2025, 4, 2),
            pickup_code=901,
        )
        OrderItem.objects.create(
            order=cls.order,
            product=cls.product,
            article_snapshot=cls.product.article,
            quantity=2,
        )

    def test_guest_can_open_product_list(self):
        response = self.client.get(reverse("catalog:product_list"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Тестовый товар")

    def test_client_does_not_see_filter_panel(self):
        self.client.login(username="client@example.com", password="testpass123")
        response = self.client.get(reverse("catalog:product_list"))
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.context["can_filter"])
        self.assertNotContains(response, 'id="product-filter-form"', html=False)

    def test_manager_can_filter_products(self):
        self.client.login(username="manager@example.com", password="testpass123")
        response = self.client.get(
            reverse("catalog:product_list"),
            {"search": "TEST01", "sort": "discount_desc"},
            HTTP_X_REQUESTED_WITH="XMLHttpRequest",
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Тестовый товар")

    def test_admin_cannot_delete_product_used_in_order(self):
        self.client.login(username="admin@example.com", password="testpass123")
        response = self.client.post(reverse("catalog:product_delete", args=[self.product.pk]))
        self.assertRedirects(response, reverse("catalog:product_list"))
        self.assertTrue(Product.objects.filter(pk=self.product.pk).exists())
