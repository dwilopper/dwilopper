from django.contrib.auth.models import AbstractUser
from django.db import models


class UserRole(models.TextChoices):
    ADMIN = "admin", "Администратор"
    MANAGER = "manager", "Менеджер"
    CLIENT = "client", "Авторизованный клиент"


class User(AbstractUser):
    full_name = models.CharField("ФИО", max_length=255)
    role = models.CharField("Роль", max_length=20, choices=UserRole.choices)
    email = models.EmailField("Электронная почта", blank=True)

    class Meta:
        ordering = ["full_name", "username"]
        verbose_name = "Пользователь"
        verbose_name_plural = "Пользователи"

    def save(self, *args, **kwargs):
        if self.username:
            self.email = self.username
        super().save(*args, **kwargs)

    def __str__(self):
        return self.full_name or self.username

    @property
    def is_admin_role(self) -> bool:
        return self.role == UserRole.ADMIN

    @property
    def is_manager_role(self) -> bool:
        return self.role == UserRole.MANAGER

    @property
    def is_client_role(self) -> bool:
        return self.role == UserRole.CLIENT
